public enum ActionOnConditionFail
{
    DontDraw,       // If condition(s) are false, don't draw the field at all.
    JustDisable,    // If condition(s) are false, just set the field as disabled.
}
