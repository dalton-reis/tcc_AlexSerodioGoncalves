﻿namespace Terrain.Generation.Configurations
{
    public class ThermalErosionConfig
    {
        public float Talus { get; set; }
        public float Strength { get; set; }
        public int Iterations { get; set; }
    }
}
